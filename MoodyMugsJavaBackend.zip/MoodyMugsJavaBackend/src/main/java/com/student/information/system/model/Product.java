package com.student.information.system.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

/**
 * @author ragcrix
 */
@Document(collection = "product")
public class Product {
    @Id
    private String id;
    public String name;
    public String image;
    public String description;
    public Number price;
    public Number rating;
    public Number numReviews;

    public Product() {
    }
    
    public Product(String name, String image, String description, Number price, Number rating, Number numReviews) {
      this.name = name;
      this.image = image;
      this.description = description;
      this.price = price;
      this.rating = rating;
      this.numReviews = numReviews;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() { 
      return name;
    }
    public void setName(String name) { 
      this.name = name;
    }
    public String getImage() { 
      return image;
    }
    public void setImage(String image) {
      this.image = image;
    }
    public String getDescription() {
      return description;
    }
    public void setDescription(String description) {
      this.description = description;
    }
    public Number getPrice() { 
      return price; 
    }
    public void setPrice(Number price) { 
      this.price = price; 
    }
    public Number getRating() { 
      return rating; 
    }
    public void setRating(Number rating) { 
      this.rating = rating; 
    }
    public Number getNumReviews() { 
      return numReviews;
    }
    public void setNumReviews(Number numReviews) { 
      this.numReviews = numReviews; 
    }  
}
