package com.student.information.system.service;

import com.student.information.system.model.Product;

import java.util.List;

/**
 * @author regcrix
 */
public interface ProductService {

    List<Product> findAll();  

}
