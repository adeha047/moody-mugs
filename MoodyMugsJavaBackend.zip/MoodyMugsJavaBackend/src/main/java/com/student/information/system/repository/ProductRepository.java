package com.student.information.system.repository;

import com.student.information.system.model.Product;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

/**
 * @author ragcrix
 */

// No need implementation, just one interface, and you have CRUD, thanks Spring Data!
public interface ProductRepository extends MongoRepository<Product, String> {
  Product findByName(String name);
}
